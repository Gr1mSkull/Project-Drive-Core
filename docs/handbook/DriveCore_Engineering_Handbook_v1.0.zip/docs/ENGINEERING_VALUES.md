Truth over assumptions.
Evidence over confidence.
Architecture over implementation.